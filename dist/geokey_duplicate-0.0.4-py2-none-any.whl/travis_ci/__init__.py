"""Travis CI configuration and runner for GeoKey."""
