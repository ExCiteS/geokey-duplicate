media_keys = ['file_id', 'file_type', 'contribution_id', 'creator',
    'creator_id', 'created_at', 'url']

comment_keys = ['comment_id', 'contribution_id', 'creator', 'creator_id',
    'created_at', 'respondsto', 'text']

keys_obs = ['geom', 'id', 'creator', 'creator_id', 'created_at', 'status']
